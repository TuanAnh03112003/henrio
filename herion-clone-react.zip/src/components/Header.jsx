function Header() {
  return (
    <section>
      <h2>Header Section</h2>
    </section>
  );
}

export default Header;
