function Events() {
  return (
    <section>
      <h2>Events Section</h2>
    </section>
  );
}

export default Events;
