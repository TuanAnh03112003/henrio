function Hero() {
  return (
    <section>
      <h2>Hero Section</h2>
    </section>
  );
}

export default Hero;
