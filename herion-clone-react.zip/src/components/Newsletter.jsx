function Newsletter() {
  return (
    <section>
      <h2>Newsletter Section</h2>
    </section>
  );
}

export default Newsletter;
