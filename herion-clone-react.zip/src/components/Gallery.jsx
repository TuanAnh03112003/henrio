function Gallery() {
  return (
    <section>
      <h2>Gallery Section</h2>
    </section>
  );
}

export default Gallery;
