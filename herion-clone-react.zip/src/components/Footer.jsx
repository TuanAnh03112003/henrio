function Footer() {
  return (
    <section>
      <h2>Footer Section</h2>
    </section>
  );
}

export default Footer;
