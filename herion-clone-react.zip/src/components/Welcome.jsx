function Welcome() {
  return (
    <section>
      <h2>Welcome Section</h2>
    </section>
  );
}

export default Welcome;
